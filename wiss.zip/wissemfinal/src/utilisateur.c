#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "utilisateur.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>


//fonction ajout client
void ajouter_utilisateur(utilisateur x) 
{
FILE *f ;
f = fopen("utilisateur.txt","a+");
if ( f != NULL )
fprintf(f,"%s %s %s %s %s \n",x.nom,x.prenom,x.fonction,x.id,x.sexe) ;
fclose (f) ;
}

//fonction suprim client
int suprimer_utilisateur(char fichier[],char iden[])
{
FILE *f ;
FILE *p ;
int n = 0 ;
char nom[20] ;
char prenom[20] ;
char fonction[40] ;
char id[10] ;
char sexe[7];
f = fopen(fichier,"a+");
p = fopen("temporaire.txt","a");
if ( f != NULL )
{
while(fscanf(f,"%s %s %s %s %s \n",nom,prenom,fonction,id,sexe)!=EOF)
{if (strcmp(iden,id) != 0 )
fprintf(p,"%s %s %s %s %s \n",nom,prenom,fonction,id,sexe);
  else
n=1;
}
fclose(f);
fclose(p);

}
if (n==1)
{
 remove(fichier) ;
 rename("temporaire.txt",fichier) ;
return 1 ;
}
else
remove("temporaire.txt");
return 0 ;
}

//fonction modifier
int modifier_utilisateur(char fichier[],utilisateur x)
{

FILE *f ;
FILE *p ;
int n = 0 ;
char ch1[20] ;
char ch2[20] ;
char ch3[40] ;
char ident[10] ;
char sex[7];
f = fopen(fichier,"a+");
p = fopen("temporaire.txt","a");
if ( f != NULL )
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,ident,sex)!=EOF)
{if(strcmp(x.id,ident)!=0)
fprintf(p,"%s %s %s %s %s \n",ch1,ch2,ch3,ident,sex);
  else
{ 
fprintf(p,"%s %s %s %s %s \n",x.nom,x.prenom,x.fonction,x.id,x.sexe);
n=1;
}
}

fclose(f);
fclose(p);
}
 if (n==1)
{
 remove(fichier) ;
 rename("temporaire.txt",fichier) ;
return 1 ;
}
else
{
remove("temporaire.txt") ; 
return 0;
}
}

//fonction recherche

utilisateur recherche(char fichier[],char x[])
{
int test = 0 ;
utilisateur c ;
utilisateur vide = {"--","--","--","--","--"};
FILE *f ;
char ch1[20] ;
char ch2[20] ;
char ch3[40] ;
char  iden[10] ;
char sex[7];
f=fopen(fichier,"a+");
if (f != NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,iden,sex)!=EOF)
{
if (strcmp(x,iden)==0 )
{strcpy(c.nom,ch1);
 strcpy(c.prenom,ch2);
 strcpy(c.fonction,ch3);
 strcpy(c.id,iden) ;
 strcpy(c.sexe,sex);
 test = 1 ;
}
}
fclose(f) ;
}
if ( test == 1 )
return(c); 
else
return (vide);
}

//fonction affichage
enum
{   ENOM,
    EPRENOM,
    Efonction,
    EID,
    ESEXE,
    COLUMNS,
};

void affichage (char fichier[],GtkWidget *liste) 
{
	GtkCellRenderer *renderer ;
	GtkTreeViewColumn *column ;
	GtkTreeIter iter ;
	GtkListStore *store ;

	char nom[20] ;
	char prenom[20] ;
	char fonction[40] ;
	char id [10];
	char sexe[7];
	store=NULL ;
	FILE *f ;
	store =gtk_tree_view_get_model(liste);
if(store == NULL )
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("fonction",renderer,"text",Efonction,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen(fichier,"a+");
if (f != NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",nom,prenom,fonction,id,sexe) != EOF )
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,Efonction,fonction,EID,id,ESEXE,sexe,-1);
}
fclose(f) ;
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
g_object_unref(store);
}
}

void affichage_etages(GtkWidget *liste){
		
	GtkCellRenderer *renderer ;
	GtkTreeViewColumn *column ;
	GtkTreeIter iter ;
	GtkListStore *store ;

	FILE *f=NULL;
	int  jour, heure, num_etage;
	float valeur;

	char strJour[20];
	char strHeure[20];
	char strNum_Etage[20];

	store =gtk_tree_view_get_model(liste);
if(store == NULL )
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",0,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("num etage",renderer,"text",2,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new(3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("debit.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %d %d %f \n",&jour, &heure, &num_etage, &valeur)!=EOF){
if(valeur>29.00){
gtk_list_store_append(store,&iter);
sprintf(strJour,"%d",jour);
sprintf(strHeure,"%d",heure);
sprintf(strNum_Etage,"%d",num_etage);
gtk_list_store_set(store,&iter,0,strJour,1,strHeure,2,strNum_Etage,-1);
}
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
g_object_unref(store);
}

int verifier(char x[])
{

FILE *f;
char ch1[20];
char ch2[20];
char ch3[20];
char id[10];
char sex[7];

f=fopen("utilisateur.txt","a+");
if (f !=NULL);
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,id,sex)!=EOF)
{      
if (strcmp(x,id)==0 )
return 1 ;

}
fclose(f) ;
}
return 0 ;
}        


void etage_panne(int *e1, int *e2, int *e3){
	FILE *f=NULL;
	int  jour, heure, num_etage;
	float valeur;

	f=fopen("debit.txt","r");
	if(f!=NULL){
		while(fscanf(f,"%d %d %d %f \n",&jour, &heure, &num_etage, &valeur)!=EOF){
			if(valeur>29.00){
				if(num_etage==1)
					*e1 = 1;
				if(num_etage==2)
					*e2 = 1;
				if(num_etage==3)
					*e3 = 1;
			}
		}
	}
	fclose(f);
}


int verif(char log[], char Pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("login.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s " ,ch1,ch2)!=EOF)
{
if((strcmp(ch1,log)==0)&&(strcmp(ch2,Pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);

}
int verif2(char log[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];

f=fopen("login.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s " ,ch1)!=EOF)
{
if((strcmp(ch1,log)==0))
trouve=1;
}
fclose(f);
}
return (trouve);

}

