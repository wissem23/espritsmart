#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "utilisateur.h"

int x=0;
int k=0;
int y=0;
int z=0 ;
int e=0;
int q=0;
char iden[20];
utilisateur cli ;
int w ;
int m;
char idd[20];


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom ;
gchar* prenom;
gchar* fonction;
gchar* id;
gchar* sexe;
utilisateur c;

char fichier[]={"utilisateur.txt"};

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&fonction,3,&id,4,&sexe,-1);

strcpy(c.id,id);
strcpy(c.nom,nom);
strcpy(c.prenom,prenom);
strcpy(c.fonction,fonction);
strcpy(c.sexe,sexe);

strcpy(idd,c.id);

//affichage(fichier,treeview);
}

}

//boutton rechercher utilisateur
void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1;

char fichier[]={"test.txt"};
char fichierr[]={"utilisateur.txt"};
char x [10];
utilisateur c ;
//partie recherche identite
window_ajouter=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry1");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
c=recherche(fichierr,x);
//partie fichier test
FILE *f;
f = fopen(fichier,"a+");
if ( f != NULL )
fprintf(f,"%s %s %s %s %s \n",c.nom,c.prenom,c.fonction,c.id,c.sexe) ;
fclose (f) ;

//partie affichage
GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1=lookup_widget(input,"treeview1");
affichage(fichier,treeview1);
remove(fichier);
}

//boutton ajouter menu utilisateur
void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
GtkWidget *combobox1;
input=lookup_widget(objet,"window2");
input=create_window2();
gtk_widget_show(input);
combobox1 = lookup_widget(input,"combobox1");
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),"Homme");
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),"Femme");
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
}

//boutton afficher utilisateur
void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
char fichier[]={"utilisateur.txt"};
GtkWidget *input,*input1,*treeview1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1=lookup_widget(input,"treeview1");
affichage(fichier,treeview1);
}

//boutton modifier menu utilisateur
void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4,*input2,*treeview1,*output,*output1,*output2,*output3,*output4,*output5,*output6;
GtkWidget *input,*input1;

char fichierr[]={"utilisateur.txt"};
char x [10];
int s ;
int n=0 ;
utilisateur c;


window1=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry10");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if ( s==0)
{
output5 = lookup_widget(objet,"label37") ;
gtk_label_set_text(GTK_LABEL(output5),"utilisateur introuvable");
n=1;
}
else
{window4=lookup_widget(objet,"window4");
window4=create_window4();
gtk_widget_show(window4);
gtk_widget_destroy(window1);
strcpy(iden,x);
n=1;
}
}
if(n==0)
{
output6 = lookup_widget(objet,"label37") ;
gtk_label_set_text(GTK_LABEL(output6),"il faut donner identifiant");
}


}

/*boutton suprimer utilisateur
void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1,*output,*output1;
GtkWidget *input,*input1,*input3;
GtkWidget *treeview1;
GtkTreeIter iter;

char fichierr[]={"utlisateur.txt"};
char x [20];
int s ;
int n=0 ;
gchar nom;
gchar prenom;
gchar fonction;
gchar id;
gchar sex;

GtkTreeModel *model = gtk_tree_view_get_model(treeview1); 

window_ajouter=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry11");

if(gtk_treeview_model_get_iter(model, $iter, path){
gtk_tree_model_get(GTK_LIST_SOTRE(model), $iter, 0, $nom, 1, $prenom, 2, $fonction, 3, $id, 4, $sex, -1);

}
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if (s==0)
{
output = lookup_widget(objet,"label36") ;
gtk_label_set_text(GTK_LABEL(output),"utilisateur introuvable");
n=1;
}
else
{//partie affichage

input3=lookup_widget(objet,"window6");
input3=create_window6();
gtk_widget_show(input3);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
//treeview1=lookup_widget(input,"treeview1");
//affichage(fichierr,treeview1);
n=1;
strcpy(idd,x);
}
}
if(n==0)
{
output1 = lookup_widget(objet,"label36") ;
gtk_label_set_text(GTK_LABEL(output1),"il faut donner identifiant");
}
}*/

//boutton ajouter pour utilisateur
void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2,*input3,*input4,*output,*output1,*output2;
GtkWidget *window_ajouter,*combobox1;
utilisateur c;
int test ;
int n = 0 ;


window_ajouter=lookup_widget(objet_graphique,"window2");

input1=lookup_widget(objet_graphique,"entry2");
input2=lookup_widget(objet_graphique,"entry3");
input3=lookup_widget(objet_graphique,"entry4");
input4=lookup_widget(objet_graphique,"entry5");

strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.fonction,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input4)));
combobox1=lookup_widget(window_ajouter,"combobox1");

if(strcmp("Femme",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
{strcpy(c.sexe,"Femme");}
if(strcmp("Homme",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
{strcpy(c.sexe,"Homme");}
test = verifier(c.id);
while((strcmp(c.nom,"")!=0)&&(strcmp(c.prenom,"")!=0)&&(strcmp(c.fonction,"")!=0)&&(strcmp(c.id,"")!=0)&&(n==0))
{
if(test==1)
{
output = lookup_widget(objet_graphique,"label7") ;
gtk_label_set_text(GTK_LABEL(output),"identite deja existe");
n=1;
}
else
{
cli=c ;
GtkWidget *input0,*input00;
input0=lookup_widget(objet_graphique,"window5");
input0=create_window5();
gtk_widget_show(input0);
input00=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input00);
n=1;

}
}
if(n==0)
{
output2=lookup_widget(objet_graphique,"label7");
gtk_label_set_text(GTK_LABEL(output2),"remplir tout les informations!");
}
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window2");
gtk_widget_destroy(input1);
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}

//boutton afficher (modification utilisateur)
void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *output,*output1,*output2,*output3,*output4;
utilisateur c ;
char fichier[]={"utilisateur.txt"};
c=recherche(fichier,iden);
output = lookup_widget(objet,"label29") ;
gtk_label_set_text(GTK_LABEL(output),c.nom);
output1 = lookup_widget(objet,"label30") ;
gtk_label_set_text(GTK_LABEL(output1),c.prenom);
output2 = lookup_widget(objet,"label33") ;
gtk_label_set_text(GTK_LABEL(output2),c.id);
output3 = lookup_widget(objet,"label32") ;
gtk_label_set_text(GTK_LABEL(output3),c.fonction);
output4 = lookup_widget(objet,"label31") ;
gtk_label_set_text(GTK_LABEL(output4),c.sexe);
}


void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window3");
gtk_widget_destroy(input1);
}


void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*output1,*output2,*output3;
GtkWidget *window3;

utilisateur x;
int m ;
int test ;
int n=0;
char fichierr[]={"utilisateur.txt"};
char text1[6]="Homme";
char text2[6]="Femme";
window3=lookup_widget(objet,"window3");
if(y==1)
strcpy(x.sexe,text1);
if(y==2)
strcpy(x.sexe,text2);


input1=lookup_widget(objet,"entry6");
input2=lookup_widget(objet,"entry7");
input3=lookup_widget(objet,"entry9");
input4=lookup_widget(objet,"entry8");


strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(input1)));//nom modifiée
strcpy(x.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));//prenom modifiée
strcpy(x.id,gtk_entry_get_text(GTK_ENTRY(input3)));//id 
strcpy(x.fonction,gtk_entry_get_text(GTK_ENTRY(input4)));//fonction modifiéé



//partie validation de modification

test = verifier(x.id);

while((strcmp(x.nom,"")!=0)&&(strcmp(x.prenom,"")!=0)&&(strcmp(x.fonction,"")!=0)&&(strcmp(x.id,"")!=0)&&(n==0))
{
if (test==1)
{

m =modifier_utilisateur(fichierr,x);
output1 = lookup_widget(objet,"label35") ;
gtk_label_set_text(GTK_LABEL(output1),"le utilisateur modifié avec succes");
n=1;
}
else
{
output2 = lookup_widget(objet,"label35") ;
gtk_label_set_text(GTK_LABEL(output2),"identifiant n'existe pas");
n=1;
}
}
if(n==0)
{
output3 = lookup_widget(objet,"label35") ;
gtk_label_set_text(GTK_LABEL(output3),"il faut remplir tout les information");
}
}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=1;}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=2;}
}


void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1,*input3,*input4,*input5;
if(z==1)
{
input=lookup_widget(objet,"window3");
input=create_window3();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
input3=lookup_widget(objet,"window4");
gtk_widget_destroy(input3);
}
if(z==2)
{
input4=lookup_widget(objet,"window1");
input4=create_window1();
gtk_widget_show(input4);
input5=lookup_widget(objet,"window4");
gtk_widget_destroy(input5);

}
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{w=1;}
else
{w=0;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{m=1;}
else
{m=0;}
}


void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int n = 0 ;
while((m!=w)&&(n==0))
{
if(w==1)
{
ajouter_utilisateur(cli);
GtkWidget *input,*input1,*input2;
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input1);
input2=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input2);
n=1;
}
if(m==1)
{
GtkWidget *input3,*input4;
input4=lookup_widget(objet_graphique,"window2");
input4=create_window2();
gtk_widget_show(input4);
input3=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input3);
n=1;
}
}
if(n==0)
{
GtkWidget *output2,*input5;
input5=lookup_widget(objet_graphique,"window5");
output2 = lookup_widget(objet_graphique,"label44") ;
gtk_label_set_text(GTK_LABEL(output2),"choisir oui ou non");
}
}


void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *spinbutton1;
GtkWidget *input,*input1,*input2,*input3,*input4,*treeview1;
char fichierr[]={"utilisateur.txt"};
int a,s ;
spinbutton1=lookup_widget(objet_graphique,"spinbutton1");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
if(a==1)
{
s=suprimer_utilisateur(fichierr,idd);
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
treeview1=lookup_widget(input,"treeview1");
affichage(fichierr,treeview1);
}
if(a==0)
{
input3=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input3);
input2=lookup_widget(objet_graphique,"window1");
input2=create_window1();
gtk_widget_show(input2);
treeview1=lookup_widget(input3,"treeview1");
affichage(fichierr,treeview1);
}
}





void
on_button37_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *etage1;
	GtkWidget *etage2;
	GtkWidget *etage3;
	int e1 = 0;
	int e2 = 0;
	int e3 = 0;

	window1 = lookup_widget(objet,"window1");
	etage1 = lookup_widget(window1,"etage1");
	etage2 = lookup_widget(window1,"etage2");
	etage3 = lookup_widget(window1,"etage3");

	gtk_widget_hide(etage1);
	gtk_widget_hide(etage2);
	gtk_widget_hide(etage3);
	
	etage_panne(&e1,&e2,&e3);

	if(e1 == 1)
		gtk_widget_show(etage1);
	else if(e2 == 1)
		gtk_widget_show(etage2);
	else if(e3 == 1)
		gtk_widget_show(etage3);


}


void
on_button38_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window8, *window1;
	
	window1 = create_window1();
	window8 = lookup_widget(button,"window8");
	gtk_widget_show(window1);
	gtk_widget_hide(window8);
}


void
on_button39_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

 	GtkWidget *window8, *window7;
	GtkWidget *treeview2;
	char fichier[]={".txt"};

	window7 = create_window7();
	window8 = lookup_widget(button,"window8");
	treeview2 = lookup_widget(window7,"treeview2");
	gtk_widget_show(window7);
	gtk_widget_hide(window8);

	affichage_etages(treeview2);
}


void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window7, *window8;
	
	window8 = create_window8();
	window7 = lookup_widget(button,"window7");
	gtk_widget_show(window8);
	gtk_widget_hide(window7);
}


void
on_button36_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ 	
	GtkWidget *window8, *window1;
	
	window8 = create_window8();
	window1 = lookup_widget(button,"window1");
	gtk_widget_show(window8);
	gtk_widget_hide(window1);
}


void
on_button41_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input3, *input1;
GtkWidget *label99;
label99 = lookup_widget(button,"label99");
if(strcmp(idd,"")==0){
gtk_widget_show(label99);
} else {
input3=lookup_widget(button,"window6");
input3=create_window6();
gtk_widget_show(input3);
input1=lookup_widget(button,"window1");
gtk_widget_destroy(input1);
}
}


GtkWidget *window8;
void
on_wisscheckbutton1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_wissbuttonenreg_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *inscription;
GtkWidget *login;
FILE *f=NULL;
GtkWidget *usn,*pw, *out, *admin;
char login1[20];
char passw[20];
int exist;
char ad[10];
usn = lookup_widget (objet_graphique,"insc_us");
pw = lookup_widget (objet_graphique,"insc_pwd");
out= lookup_widget (objet_graphique,"mout");
strcpy(login1, gtk_entry_get_text(GTK_ENTRY(usn)));
strcpy(passw, gtk_entry_get_text(GTK_ENTRY(pw)));
/*if(gtk_check_button_is_active(admin)){
strcpy(ad,"yes");
}else{strcpy(ad,"no");}*/
f=fopen("login.txt","a");

exist=verif2(login1);
if(f!=NULL)
{
if(exist==-1){
fprintf(f,"%s %s %s \n",login1,passw,ad);
fclose(f);
login= create_login ();
gtk_widget_show(login);
inscription=lookup_widget(objet_graphique,"inscription");
gtk_widget_destroy(inscription);}

}else{
gtk_label_set_text(GTK_LABEL(out),"utilisateur déja existant !");}
}


void
on_wissbuttonannuler_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *inscription;
GtkWidget *login;

login= create_login ();
gtk_widget_show(login);
inscription=lookup_widget(objet_graphique,"inscription");
gtk_widget_destroy(inscription);
}


void
on_wissincri_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *login;
GtkWidget *inscription;

inscription= create_inscription ();
gtk_widget_show(inscription);
login=lookup_widget(objet_graphique,"login");
gtk_widget_destroy(login);
}


void
on_wissconnect_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *login;
GtkWidget *username, *password , *output;
char user[20];
char pasw[20];
int trouve;
username=lookup_widget (objet_graphique,"entry_us");
password=lookup_widget (objet_graphique,"entry_pwd");
output= lookup_widget (objet_graphique,"msg");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{

window8=lookup_widget(objet_graphique,"window8");
window8=create_window8();

gtk_widget_show(window8);
login=lookup_widget(objet_graphique,"login");
gtk_widget_hide(login);
}
}

void
on_youtube_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.youtube.com");
}


void
on_facebook_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.facebook.com/boubiw1");
}


void
on_instagram_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.instagram.com/wissem_chehoumi/?hl=en");
}


void
on_web_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.esprit.tn");
}










void
on_buttonquitter_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *login;
GtkWidget *window8;

login= create_login ();
gtk_widget_show(login);
window8=lookup_widget(objet_graphique,"window8");
gtk_widget_destroy(window8);
}
