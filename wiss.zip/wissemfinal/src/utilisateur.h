#include <gtk/gtk.h>
typedef struct 
{   
    char nom[20] ;
    char prenom[20] ;
    char fonction[40] ;
    char id[10] ;
    char sexe[7];
}utilisateur;




void affichage (char fichier[],GtkWidget *liste) ; 

void achiffage_etages(GtkWidget *liste);

utilisateur recherche(char fichier[],char x[] );

void ajouter_utilisateur(utilisateur x) ; 

int suprimer_utilisateur(char fichier[],char iden[]) ;

int modifier_utilisateur(char fichier[],utilisateur x) ;

int verifier(char x[]) ;

void etage_panne(int *e1, int *e2, int *e3);


